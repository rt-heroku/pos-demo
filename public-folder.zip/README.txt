# Public folder
This directory contains the browser assets for the POS app.

Loaded in this order:
1) icons.js
2) modals.js
3) views.js (with an injected minimal SettingsView to avoid React error #130)
4) enhanced-pos.js
5) api.js
6) app.js

Open http://localhost:3000/ (server serves /public) to run.
